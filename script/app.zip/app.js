function addCommentToUI(comment) {
  const photoElement = document.querySelector(`#photo-${comment.photo_id}`);
  const commentList = photoElement.querySelector('.comment-list');
  const commentHTML = createCommentHTML(comment);
  commentList.innerHTML += commentHTML;
}

function createCommentHTML(comment) {
  return `
    <li id="comment-${comment.id}">
      ${comment.comment_text} - ${comment.username}
      <a href="#" class="delete-comment-icon" data-photo-id="${comment.photo_id}" data-comment-id="${comment.id}">X</a>
    </li>
  `;
}

function getPhotos(refresh = false) {
  const method = 'GET';
  let url = 'get.php';

  if (refresh) {
    url += '?_ts=' + new Date().getTime();
  }

  fetch(url, {
    method: method,
  })
    .then(response => response.json())
    .then(data => {
      console.log(data);
      const photos = data;
      let html = '';
      let counter = 0; // count the number of photos added to the row

      photos.forEach(photo => {
        // If the counter is 0, start a new row
        if (counter === 0) {
          html += '<div class="row">';
        }

        html += '<div class="col-md-6">';
        html += '<div class="card mb-4 box-shadow">';
        html += '<img class="card-img-top" src="' + photo.filename + '" alt="' + photo.caption + '">';
        html += '<div class="card-body">';
        html += '<p class="card-text">' + photo.caption + '</p>';

        // add comments for the photo
        html += '<h5>Comments</h5>';
        html += '<ul>';
        if(photo.comments.length > 0){
          photo.comments.forEach(comment => {
            html += '<li id="comment-' + comment.id + '">' + comment.comment_text + ' - ' + comment.username + ' <a href="#" class="delete-comment-icon" data-photo-id="' + photo.id + '" data-comment-id="' + comment.id + '">X</a></li>';
          });
        } else {
          html += '<li>No comments yet.</li>';
        }
        html += '</ul>';

        // add comment form for the photo
        html += '<form class="comment-form">';
        html += '<div class="form-group">';
        html += '<input type="hidden" name="photo_id" value="' + photo.id + '">';
        html += '<label for="comment_text">Add Comment</label>';
        html += '<input type="text" class="form-control" id="comment_text" name="comment_text">';
        html += '</div>';
        html += '<button type="submit" class="btn btn-primary add-comment-btn">Submit</button>';
        html += '</form>';

        // add delete button for the photo
        html += '<button class="btn btn-danger delete-photo-btn" data-photo-id="' + photo.id + '">Delete</button>';

        html += '</div>';
        html += '</div>';
        html += '</div>';

        // Increment the counter
        counter++;

        // If the counter is 2, end the row and reset the counter
        if (counter === 2) {
          html += '</div>';
          counter = 0;
        }
      });

      // If there is an odd number of photos, close the last row
      if (counter === 1) {
        html += '</div>';
      }

      document.getElementById('photo-gallery').innerHTML = html;

      // Add event listener for delete photo buttons
      const deletePhotoButtons = document.querySelectorAll('.delete-photo-btn');
      deletePhotoButtons.forEach(button => {
        button.addEventListener('click', deletePhoto);
      });

      // Add event listener for comment form submissions
      const commentForms = document.querySelectorAll('.comment-form');
      commentForms.forEach(form => {
        form.addEventListener('submit', addComment);
      });

      // Add event listener for delete comment icons
      const deleteCommentIcons = document.querySelectorAll('.delete-comment-icon');
      deleteCommentIcons.forEach(icon => {
        icon.addEventListener('click', deleteComment);
    });
  })
  .catch(error => console.log(error));
}

  window.onload = function() {
    getPhotos();
  };

  function uploadPhoto(event) {
    event.preventDefault();
  
    const form = document.getElementById('upload-form');
    const formData = new FormData(form);
  
    fetch('post.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.json())
      .then(data => {
        // Update the cache/session with the newly uploaded photo
        const currentPhotos = JSON.parse(sessionStorage.getItem('photos'));
        const updatedPhotos = currentPhotos ? [...currentPhotos, data] : [data];
        sessionStorage.setItem('photos', JSON.stringify(updatedPhotos));
  
        // Refresh the photo gallery to show the newly uploaded photo
        getPhotos(true);
      })
      .catch(error => {
        console.error(error);
        // alert('Error uploading photo. Please try again.');
      });
  }
  
  
  const form = document.querySelector('#upload-form');
  const submitBtn = document.querySelector('#upload-btn');
  
  submitBtn.addEventListener('click', uploadPhoto);

  // function addComment(event) {
  //   event.preventDefault();
  
  //   const formData = new FormData(event.target);
  
  //   fetch('comments.php', {
  //     method: 'POST',
  //     body: formData
  //   })
  //     .then(response => response.json())
  //     .then(data => {
  //       if (data.status === 'success') {
  //         // Update the cache/session with the newly added comment
  //         const currentComments = JSON.parse(sessionStorage.getItem('comments'));
  //         const updatedComments = currentComments ? [...currentComments, data] : [data];
  //         sessionStorage.setItem('comments', JSON.stringify(updatedComments));

  //         // Refresh the photo gallery to show the newly added comment
  //         getPhotos(true);
  //       } else {
  //         // Handle the error response
  //         console.error(data.error);
  //         alert('Error adding comment. Please try again.');
  //       }
  //     })
  //     .catch(error => {
  //       console.error(error);
  //       alert('Error adding comment. Please try again.');
  //     });
  // }
  function addComment(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
  
    fetch('comments.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        const comment = {
          id: data.id,
          photo_id: data.photo_id,
          username: data.username,
          comment_text: data.comment_text
        };
        addCommentToUI(comment);
        form.reset();
      } else {
        console.log(data.message);
      }
    })
    .catch(error => console.log(error));
  }
  

const commentForm = document.querySelector('#comment-form');
commentForm.addEventListener('submit', addComment);

function deletePhoto(event) {
  const photoId = event.target.dataset.photoId;
  if (!photoId) {
    console.error('Photo ID not found');
    return;
  }

  const confirmed = confirm('Are you sure you want to delete this photo?');
  if (!confirmed) {
    return;
  }

  const method = 'DELETE';
  const url = 'delete.php?id=' + photoId;

  fetch(url, {
    method: method,
  })
    .then(response => response.text())
    .then(data => {
      console.log(data); // log the response data to the console
      // Update the cache/session by removing the deleted photo
      const currentPhotos = JSON.parse(sessionStorage.getItem('photos'));
      const updatedPhotos = currentPhotos.filter(photo => photo.id !== photoId);
      sessionStorage.setItem('photos', JSON.stringify(updatedPhotos));

      // Reload the page to show the updated list of photos
      window.location.reload(true);
    })
    .catch(error => console.error(error));
}

// // function to delete comment
// function deleteComment(event) {
//   event.preventDefault();

//   const photoId = event.target.getAttribute('data-photo-id');
//   const commentId = event.target.getAttribute('data-comment-id');

//   if (!photoId || !commentId) {
//     console.error('Invalid photo ID or comment ID');
//     return;
//   }

//   const url = `delete_comment.php?photo_id=${photoId}&comment_id=${commentId}`;

//   fetch(url, {
//     method: 'DELETE',
//   })
//     .then(response => {
//       if (!response.ok) {
//         throw new Error('Network response was not ok');
//       }
//       console.log(`Comment ${commentId} was deleted successfully`);
//       getPhotos();
//     })
//     .catch(error => {
//       console.error(`There was an error deleting the comment: ${error.message}`);
//     });
// }

// function to delete comment
function deleteComment(photoId, commentId) {
  fetch(`delete_comment.php?photo_id=${photoId}&comment_id=${commentId}`, {
    method: 'DELETE'
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('There was an error deleting the comment');
    }
    return response.json();
  })
  .then(data => {
    console.log(data.message);
    // reload the page to update the comments
    location.reload();
  })
  .catch(error => {
    console.error('There was an error deleting the comment:', error);
    alert('There was an error deleting the comment');
  });
}


// add event listener to delete comment icon
document.addEventListener('click', function(event) {
  const target = event.target;

  // check if the delete comment icon is clicked
  if (target.matches('.delete-comment-icon')) {
    // confirm if user wants to delete comment
    if (confirm('Are you sure you want to delete this comment?')) {
      const photoId = target.getAttribute('data-photo-id');
      const commentId = target.getAttribute('data-comment-id');
      deleteComment(photoId, commentId);
      // pass photoId and commentId to deleteComment function
    }
  }
});






